#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)b - *(int*)a );
}

int main(int argc, const char *argv[]) 
{
	/* input parameters taken by user*/
	int k, N;
	/* parameter for loops. */
	int i, j;
	/* fork return values. */
	pid_t pid;
	/* whitespace counter. */
	int wsCounter = 0;
	/* size of the input files. */
	int inputSize, intermediateSize;
	/* loop value to copy ascii value from input file and move it to an integer array */
	int inputChar, intermediateChar;
	/* copy value */
	int temp = 0;
	/* intermadiate char array */
	char *intermediate[17], *intermediateParent[17];
	/* intermediate file results. */
	char* results[100], output[100];
	/* creating an int array with size k. */
	int inputValues[10000], intermediateValues[10000];

	/* stroing the k & N values. */
	k = atoi(argv[1]);
	N = atoi(argv[2]);
	
	/* checking if the entered parameters are sufficient. */
	if(argc > 9) {
		printf("Please do not enter more than 8 parameters!\n");
		exit(0);
	} else if(argc < 4) {
		printf("Please enter at least 1 input file and only one output file with k & N values.\n");
		exit(0);
	}

	/* checking the key value if it is properly entered. */
	if(atoi(argv[1]) == 0 || atoi(argv[1]) < 1 || atoi(argv[1]) > 1000) {
		printf("please enter an integer between 1 and 1000 for the k value\n");
		exit(0);
	} else {
		k = atoi(argv[1]);
	}

	/* checking the N value if it is properly entered. */
	if(atoi(argv[2]) == 0 || atoi(argv[2]) < 1 || atoi(argv[2]) > 5) {
		printf("please enter an integer between 1 and 5 for the N value\n");
		exit(0);
	} else {
		N = atoi(argv[2]);
	}

	char *buf = (char *) calloc(10000, sizeof(char));
	char *bufParent = (char *) calloc(10000, sizeof(char));

	/* creating child processes with respect to the number of input files */
	for(i = 0 ; i < N ; i++)
	{
		pid = fork();
		
		/* child processes. */
		if(pid == 0)
		{
			/* open input files concurrently by child processes. */
			int fd = open(argv[3 + i], O_RDONLY);

			/* read from the input files. */
			int sz = read(fd, buf, 10000);

			/* count the occurence of numbers in an input file. wsCounter is used to
				count the white space characters in a file, j for loop iteration variable. */
			wsCounter = 0;
			j = 0;
			while(1)
			{
				if(buf[j] == '\n' || buf[j] == '\t' || buf[j] == ' ')
				{
					wsCounter = wsCounter + 1;
				}
				else if(buf[j + 1] == 0)
				{
					break;
				}
				j++;
			}
			inputSize = wsCounter;

			/* put the numbers inside in an integer array. j is going to be used
				for loop iteration again therefore it is set to 0. Input char is used
				for inner loop. */
			j = 0;
			inputChar = 0;
			for(j = 0 ; j < inputSize ; j++)
			{
				temp = atoi(&buf[inputChar]);
				while(buf[inputChar] != 0)
				{
					if(buf[inputChar] != '\n' && buf[inputChar] != '\t' && buf[inputChar] != ' ')
					{
						inputChar++;
					}
					else
					{
						inputChar++;
						break;
					}
				}
				inputValues[j] = temp;
			}

			/* sort the array. */
			qsort(inputValues, inputSize, sizeof(int), cmpfunc);

			/* write the k largest integer values to an intermediate file. */

			/* creating a file name which is like "intermediate" than "intermediate
				file number as 1,2,3,...etc" than ".txt" extension. */
			char concatenate[1];
			strcat(intermediate, "intermediate");
			sprintf(concatenate, "%d", i + 1);
			strcat(intermediate, concatenate);
			strcat(intermediate, ".txt");

			int fdIntermediate = open(intermediate, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);

			if(fdIntermediate < 0)
			{
				perror("r2");
				exit(1);
			}

			for(j = 0 ; j < k ; j++)
			{
				sprintf(results, "%d\n", inputValues[j]);
				write(fdIntermediate, results, strlen(results));
			}

			/* close the input file.*/
			if(close(fdIntermediate) < 0)
			{
				perror("c1");
				exit(1);
			}

			/* close the input file.*/
			if(close(fd) < 0)
			{
				perror("c1");
				exit(1);
			}

			exit(0);
		} 

		/* parent process. */
		else if(pid > 0)
		{
			wait(NULL);

			/* creating a file name which is like "intermediate" than "intermediate
				file number as 1,2,3,...etc" than ".txt" extension. */
			char concatenateParent[17];
			strcat(intermediateParent, "intermediate");
			sprintf(concatenateParent, "%d", i + 1);
			strcat(intermediateParent, concatenateParent);
			strcat(intermediateParent, ".txt");

			int fdIntermediateToParent = open(intermediateParent, O_RDONLY);
			int sz = read(fdIntermediateToParent, bufParent, 10000);

			memset(intermediateParent, 0, sizeof intermediateParent);
			
			int fdParent = open(argv[N + 3], O_CREAT | O_RDWR | O_APPEND, S_IRUSR | S_IWUSR);

			intermediateChar = 0;
			for(j = 0 ; j < k ; j++)
			{
				temp = atoi(&bufParent[intermediateChar]);
				while(bufParent[intermediateChar] != 0)
				{
					if(bufParent[intermediateChar] != '\n' && bufParent[intermediateChar] != '\t' && bufParent[intermediateChar] != ' ')
					{
						intermediateChar++;
					}
					else
					{
						intermediateChar++;
						break;
					}
				}
				intermediateValues[j] = temp;
			}

			/* writing to output file. */
			for(j = 0 ; j < k ; j++)
			{
				sprintf(output, "%d\n", intermediateValues[j]);
				write(fdParent, output, strlen(output));
				if(j + 1 == k)
				{
					write(fdParent, "\n", strlen("\n"));
				}
			}
		}
	}

	/* removing intermediate files. */
	for(j = 0 ; j < N ; j++)
	{
		/* creating a file name which is like "intermediate" than "intermediate
			file number as 1,2,3,...etc" than ".txt" extension. */
		char *fileToBeRemoved[17];
		char removeConcatenate[17];
		strcat(fileToBeRemoved, "intermediate");
		sprintf(removeConcatenate, "%d", j + 1);
		strcat(fileToBeRemoved, removeConcatenate);
		strcat(fileToBeRemoved, ".txt");

		remove(fileToBeRemoved);

		memset(fileToBeRemoved, 0, sizeof fileToBeRemoved);
	}
}