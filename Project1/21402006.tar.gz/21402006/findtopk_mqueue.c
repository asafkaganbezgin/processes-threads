#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include <mqueue.h>

struct item {
    int kLargestNumbers[10000];
};

#define MQNAME "/numbers"

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)b - *(int*)a );
}

int main(int argc, const char *argv[]) 
{
    /* message queue iniialization. */
    mqd_t mq;
    struct item item;
	/* input parameters taken by user*/
	int k, N;
	/* parameter for loops. */
	int i, j;
	/* fork return values. */
	pid_t pid;
	/* whitespace counter. */
	int wsCounter = 0;
	/* size of the input files. */
	int inputSize, intermediateSize;
	/* loop value to copy ascii value from input file and move it to an integer array */
	int inputChar, intermediateChar;
	/* copy value */
	int temp = 0;
	/* intermadiate char array */
	char *intermediate[17], *intermediateParent[17];
	/* intermediate file results. */
	char* results[100], output[100];
	/* creating an int array with size k. */
	int inputValues[10000], intermediateValues[10000];

	/* stroing the k & N values. */
	k = atoi(argv[1]);
	N = atoi(argv[2]);
	
	/* checking if the entered parameters are sufficient. */
	if(argc > 9) {
		printf("Please do not enter more than 8 parameters!\n");
		exit(0);
	} else if(argc < 4) {
		printf("Please enter at least 1 input file and only one output file with k & N values.\n");
		exit(0);
	}

	/* checking the key value if it is properly entered. */
	if(atoi(argv[1]) == 0 || atoi(argv[1]) < 1 || atoi(argv[1]) > 1000) {
		printf("please enter an integer between 1 and 1000 for the k value\n");
		exit(0);
	} else {
		k = atoi(argv[1]);
	}

	/* checking the N value if it is properly entered. */
	if(atoi(argv[2]) == 0 || atoi(argv[2]) < 1 || atoi(argv[2]) > 5) {
		printf("please enter an integer between 1 and 5 for the N value\n");
		exit(0);
	} else {
		N = atoi(argv[2]);
	}

	char *buf = (char *) calloc(10000, sizeof(char));
	char *bufParent = (char *) calloc(10000, sizeof(char));

	/* creating child processes with respect to the number of input files */
	for(i = 0 ; i < N ; i++)
	{
		pid = fork();
		
		/* child processes. */
		if(pid == 0)
		{
			/* open input files concurrently by child processes. */
			int fd = open(argv[3 + i], O_RDONLY);

			/* read from the input files. */
			int sz = read(fd, buf, 10000);

			/* count the occurence of numbers in an input file. wsCounter is used to
				count the white space characters in a file, j for loop iteration variable. */
			wsCounter = 0;
			j = 0;
			while(1)
			{
				if(buf[j] == '\n' || buf[j] == '\t' || buf[j] == ' ')
				{
					wsCounter = wsCounter + 1;
				}
				else if(buf[j + 1] == 0)
				{
					break;
				}
				j++;
			}
			inputSize = wsCounter;

			/* put the numbers inside in an integer array. j is going to be used
				for loop iteration again therefore it is set to 0. Input char is used
				for inner loop. */
			j = 0;
			inputChar = 0;
			for(j = 0 ; j < inputSize ; j++)
			{
				temp = atoi(&buf[inputChar]);
				while(buf[inputChar] != 0)
				{
					if(buf[inputChar] != '\n' && buf[inputChar] != '\t' && buf[inputChar] != ' ')
					{
						inputChar++;
					}
					else
					{
						inputChar++;
						break;
					}
				}
				inputValues[j] = temp;
			}

			/* sort the array. */
			qsort(inputValues, inputSize, sizeof(int), cmpfunc);

			/* send the information to parent process via message queue. */
            mq = mq_open(MQNAME, O_RDWR);
            int n;
            if(mq == -1)
            {
                perror("mq open failed\n");
                exit(1);
            }
            
            for(j = 0 ; j < k ; j++)
            {
                item.kLargestNumbers[j] = inputValues[j];
            }

            n = mq_send(mq, (int *) &item, sizeof(struct item), 0);

			if(n == -1)
			{
				perror("mq_send_failed\n");
				exit(1);
			}

			/* close message queue. */
			mq_close(mq);

			/* close the input file.*/
			if(close(fd) < 0)
			{
				perror("c1");
				exit(1);
			}

			exit(0);
		} 

		/* parent process. */
		else if(pid > 0)
		{
			wait(NULL);
            printf("parent process\n");


			/* writing to output file. */
			// for(j = 0 ; j < k ; j++)
			// {
			// 	sprintf(output, "%d\n", intermediateValues[j]);
			// 	write(fdParent, output, strlen(output));
			// 	if(j + 1 == k)
			// 	{
			// 		write(fdParent, "\n", strlen("\n"));
			// 	}
			// }
		}
	}
}