#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

/* creating the node structure for BST. Data as integer value and left & right pointers. */
struct node
{
    int key;
    struct node *left, *right;
};

/* initial node creation when inserting in to an empty BST. */
struct node *newNode(int item)
{
    struct node *root = (struct node*)malloc(sizeof(struct node));
    root->key = item;
    root->left = NULL;
    root->right = NULL;
    
    return root;
}

/* node of the linear linkedlist. */
struct item
{
    int data;
    struct item *next;
};

/* global variables for threads to read and write. */
struct node *root = NULL;
int fileOpenCount = 0;
int lock = 0;
int sizeOfBST = 0;
char *buf[180];
int scanSuccess;
int k; 
int N;
char *outputFileName;
FILE *outputFile;

/* postOrder traversal to BST to get the items in a descending order. */
void postOrder(struct node *root)
{
    if(root != NULL)
    {
        postOrder(root->right);
        printf("%d ", root->key);
        postOrder(root->left);
    }
}

/* search the BST if a node with a given key exists. */
struct node* search(struct node* root, int key) 
{ 
    /* if the BST is empty or the root has the desired key value. */
    if (root == NULL || root->key == key) 
       return root; 
     
    /* if the key of the root is greater than the desired key. */
    if (root->key < key) 
       return search(root->right, key); 
  
    /* desired key is smaller than the key of the root. */
    return search(root->left, key); 
} 

/* inserting a new node to the BST. */
struct node* insert(struct node* node, int key)
{
    /* if the BST is empty, return the node to be inserted. */
    if(node == NULL) 
    {
        /* increase the size of the BST. */
        sizeOfBST++;
        return newNode(key);
    }

    /* if the BST is not empty, then recursively find the node which will be the parent of the newly inserted key,
        than add the new node to the corresponding place i.e. left child or right child. */
    else if(key < node->key)
    {
        node->left = insert(node->left, key);
    }
    else if(key > node->key)
    {
        node->right = insert(node->right, key);
    }

    /* return the root of the BST */
    return node;
}

/* returns the node with the minimum key value in the BST. Used to find the
    inorder successor of the node to be deleted. */
struct node* minValueNode(struct node* node)
{
    struct node* current = node;

    /* left most leaf is the node with the minimum key value */
    while(current != NULL && current->left != NULL)
    {
        current = current->left;
    }

    return current;
}

/* deleting the node with the specified key value from the BST. */
struct node* delete(struct node* root, int key)
{
    /* base case */
    if(root == NULL)
    {
        return root;
    }

    /* if the key to be deleted is less than the key value of the root
        of the tree/subtree, then recurse to the left of the tree/subtree. */
    if(key < root->key)
    {
        root->left = delete(root->left, key);
    }

    /* if the key to be deleted is greater than the key value of the root
        of the tree/subtree, then recurse to the right of the tree/subtree. */
    else if(key > root->key)
    {
        root->right = delete(root->right, key);
    }

    /* if the key to be deleted is equal to the key value of the current node,
        then delete operation starts. */
    else
    {
        /* deleting the node with only one child or no child. */
        if (root->left == NULL)
        {
            struct node *temp = root->right;
            free(root);

            /* decreasing the size of the BST. */
            sizeOfBST--;

            return temp;
        }
        else if (root->right == NULL)
        {
            struct node *temp = root->left;
            free(root);

            /* decreasing the size of the BST. */
            sizeOfBST--;

            return temp;
        }
        /* deleting the node with two children. First the inorder successor of the
            (smallest in the right subtree) should be stored in a variable. */
        else
        {
            struct node* temp = minValueNode(root->right);

            /* copying the content of the inorder successor to the  current node. */
            root->key = temp->key;

            /* deleting the inorder successor. */
            root->right = delete(root->right, temp->key);
        }
    }

    return root;
}

/* copying the BST to an integer array in a descending order. */
void writeToFile(struct node *root)
{   
    if(root != NULL)
    {
        writeToFile(root->right);
        fprintf(outputFile, "%d\n", root->key);
        writeToFile(root->left);
    }
}

/* opening than reading from the file. */
void *readAndInsert(void *param)
{
    while(lock == 1);
    
    lock = 1;
    
    /* critical section. */
    FILE *file = fopen(param, "r");
    
    if(file == NULL)
    {
        perror("Error: ");
        exit(1);
    }
    else if(file == 0)
    {
        perror("Error: ");
        exit(1);
    }
    else
    {        
        while (fscanf(file, "%s", buf) == 1)
        {
            /* processing the current number in the file. */
            int temp = atoi(buf);

            /* if the BST is empty, just insert in to it. */
            if (sizeOfBST == 0)
            {
                root = insert(root, temp);
            }

            /* if the size of the BST is less than the k value, insert the number in the BST if the
                value is greater than the minimum value in the BST. */
            else if (sizeOfBST < k)
            {
                if (minValueNode(root)->key < temp)
                {
                    root = insert(root, temp);
                }
            }

            /* if the size of the BST is equal to the k value, then first check if the key to be inserted
                is greater than the minimum key in the BST. If it is the case, delete the minimum value
                and insert the new one in the BST. */
            else if (sizeOfBST == k)
            {
                if (minValueNode(root)->key < temp && search(root, temp) == NULL)
                {
                    root = delete(root, minValueNode(root)->key);
                    root = insert(root, temp);
                }
            }
        }
    }

    fclose(file);
    
    lock = 0;
    
    pthread_exit(0);
} 

int main(int argc, char *argv[]) 
{
    /* time variables */
    clock_t startingTime, endingTime;
    double cpu_time_used;

    /* starting the clock at the beginning of the program. */
    startingTime = clock();

    /* variables. */
    char *txt = ".txt";

    /* other variables. */
    unsigned integer_size = sizeof(int);

    /* loop variables */
    int inputFileNameIterator;

    /* linear link list head pointer */
    struct item *start = NULL;

    /* stroing the k & N values. */
	k = atoi(argv[1]);
	N = atoi(argv[2]);

    /* storing output file. */
    outputFileName = argv[argc - 1];
	
	/* checking if the entered parameters are sufficient. */
	if(argc > 9) {
		printf("Please do not enter more than 8 parameters!\n");
		exit(0);
	} else if(argc < 4) {
		printf("Please enter at least 1 input file and only one output file with k & N values.\n");
		exit(0);
	}

	/* checking the k value if it is properly entered. */
	if(atoi(argv[1]) == 0 || atoi(argv[1]) < 100 || atoi(argv[1]) > 10000) {
		printf("please enter an integer between 100 and 10000 for the k value\n");
		exit(0);
	} else {
		k = atoi(argv[1]);
	}

	/* checking the N value if it is properly entered. */
	if(atoi(argv[2]) == 0 || atoi(argv[2]) < 1 || atoi(argv[2]) > 10) {
		printf("please enter an integer between 1 and 10 for the N value\n");
		exit(0);
	} else {
		N = atoi(argv[2]);
	}

    /* checking if the number of input files is equal to N */
    for (size_t i = 3; i <= argc - N ; i++)
    {
        if(strstr(argv[i], txt) == NULL)
        {
            printf("Number of input files are not equal to the N value.\n");
            exit(0);
        }        
    }
    
    pthread_t tid;
    pthread_attr_t attr;

    for(inputFileNameIterator = 0 ; inputFileNameIterator < argc - 4 ; inputFileNameIterator++)
    {
        pthread_attr_init(&attr);
        pthread_create(&tid, &attr, readAndInsert, argv[inputFileNameIterator + 3]);
        pthread_join(tid, NULL);
    }

    /* creating the output file specified by the user with write permission. */
    outputFile = fopen(outputFileName, "w");
    /* writing in to the output file. */
    writeToFile(root);
    /* closing the file. */
    fclose(outputFile);

    /* ending the clock and calculating the run time. */
    endingTime = clock();
    cpu_time_used = ((double)(endingTime - startingTime)) / CLOCKS_PER_SEC;
    printf("Execution time: %d\n", cpu_time_used);
}