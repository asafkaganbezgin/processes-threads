#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "simplefs.h"

/* global virtual disk file descriptor will be assigned with sfs_mount call
    any function in this file can use this. */
int vdisk_fd;
char disk_name[128];
int disk_size;
int disk_blockCount;

struct entryInfo
{
	int startBlock;
	int size;
	int sizeBytes;	
};

struct directEntry
{
	struct entryInfo info;
	int available;
	char fileName[32]; //maximum file name is 32 characters long
};

struct directEntry directory[MAXFILENUMBER];
int FAT[BLOCKCOUNT];

struct openFileTableEntry
{
	int available;
	struct entryInfo *info;
	int position;
	char fileName[32]; //maximum file name is 32 characters long
	int openCount;
	int mode;
};

struct openFileTableEntry openFileTable[MAXOPENFILES];
int diskLoaded = 0;

// This function is simply used to a create a virtual disk
// (a simple Linux file including all zeros) of the specified size.
// You can call this function from an app to create a virtual disk.
// There are other ways of creating a virtual disk (a Linux file)
// of certain size. 
// size = 2^m Bytes
int create_vdisk (char *vdiskname, int m)
{
    char command[BLOCKSIZE]; 
    int size;
    int num = 1;
    int count; 
    /* left shifting an integer “x” with an integer “y” (x<<y) is equivalent to 
        multiplying x with 2^y (2 raise to power y).  */
    size  = num << m;
    count = size / BLOCKSIZE;
    printf ("m: %d\nsize: %d\n", m, size);
    sprintf (command, "dd if=/dev/zero of=%s bs=%d count=%d",
	     vdiskname, BLOCKSIZE, count);
    printf ("executing command = %s\n", command); 
    system (command); 
    return (0); 
}

// read block k from disk (virtual disk) into buffer block.
// size of the block is BLOCKSIZE.
// space for block must be allocated outside of this function.
// block numbers start from 0 in the virtual disk. 
int read_block (void *block, int k)
{
    int n;
    int offset;

    offset = k * BLOCKSIZE;
    lseek(vdisk_fd, (off_t) offset, SEEK_SET);
    n = read (vdisk_fd, block, BLOCKSIZE);
    if (n != BLOCKSIZE) {
	printf ("read error\n");
	return -1;
    }
    return (0); 
}

// write block k into the virtual disk. 
int write_block (void *block, int k)
{
    int n;
    int offset;

    offset = k * BLOCKSIZE;
    lseek(vdisk_fd, (off_t) offset, SEEK_SET);
    n = write (vdisk_fd, block, BLOCKSIZE);
    if (n != BLOCKSIZE) {
	printf ("write error\n");
	return (-1);
    }
    return 0; 
}

/**********************************************************************
   The following functions are to be called by applications directly. 
***********************************************************************/

int sfs_format (char *vdiskname)
{
    strcpy (disk_name, vdiskname); 
	disk_size = MAXDISKSIZE; 
	disk_blockCount = disk_size / BLOCKSIZE; 

	vdisk_fd = open (disk_name, O_RDWR); 
	if (vdisk_fd == -1) {
		printf ("disk open error %s\n", vdiskname); 
		exit(1); 
	}
	
	// perform your format operations here. 
	printf ("formatting disk=%s, size=%d\n", vdiskname, disk_size);

	// Creating and initializing directory
	struct directEntry directory[MAXFILENUMBER];
	for (int i = 0; i < MAXFILENUMBER; i++)
	{
		directory[i].available = 1;
		directory[i].info.size = 0;
		directory[i].info.startBlock = -1;
	}

	// Creating and initializing free space manager
	// first 8 blocks to be reserved for meta-data
	/* int FAT[BLOCKCOUNT]; */
	for (int i = 0; i < BLOCKCOUNT; i++)
	{
		if(i < MINDISKSIZE)
			FAT[i] = -1;
		else
			FAT[i] = 0;
	}

	// Creating a disk block
	char block[BLOCKSIZE];

	// copying first half of the directory to the block
	memcpy(block, directory, 64*(sizeof(struct directEntry)));

	// putting the block into disk
	if(write_block(block, 1) != 0)
		return -1;

	// copying the second half of the directory to the block
	memcpy(block, &directory[64], 64*(sizeof(struct directEntry)));

	// putting the block into disk
	if(write_block(block, 2) != 0)
		return -1;

	// storing FAT in the disk from blocks 8 to 1032  
	char tempFAT[BLOCKCOUNT*sizeof(int)];
	memcpy(tempFAT, FAT, BLOCKCOUNT*sizeof(int));

	int blockNum = 8;
	/* from block 8 until block 1032 store file allocation table. */
	for(int i = 0; i < BLOCKCOUNT * sizeof(int) ; i = i + BLOCKSIZE)
	{
		memcpy(block, &tempFAT[i], BLOCKSIZE);
		write_block(block, blockNum);
		blockNum++;
	}

	fsync (vdisk_fd); 
	close (vdisk_fd); 

    return 0;

}

int sfs_mount (char *vdiskname)
{
    // simply open the Linux file vdiskname and in this
    // way make it ready to be used for other operations.
    // vdisk_fd is global; hence other function can use it. 
	struct stat sfs; 

	strcpy (disk_name, vdiskname);
	vdisk_fd = open (disk_name, O_RDWR); 
	if (vdisk_fd == -1) {
		printf ("sfs_mount: disk open error %s\n", disk_name); 
		exit(1); 
	}

	fstat (vdisk_fd, &sfs); 

	printf ("sfs_mount: mounting %s, size=%d\n", disk_name, 
		(int) sfs.st_size);  
	disk_size = (int) sfs.st_size; 
	disk_blockCount = disk_size / BLOCKSIZE; 

	// getting the directory blocks from disk	
	char block[BLOCKSIZE];
	if(read_block(block, 1) != 0)
		return -1;
	char block2[BLOCKSIZE];
	if(read_block(block2, 2) != 0)
		return -1;

	// Copying directory from the blocks
	memcpy(directory, block, 64*(sizeof(struct directEntry)));
	memcpy(&directory[64], block2, 64*(sizeof(struct directEntry)));

	// getting the FAT from disk
	char tempFAT[BLOCKCOUNT*sizeof(int)];

	int blockNum = 8;
	for(int i = 0; i < BLOCKCOUNT*sizeof(int); i = i + BLOCKSIZE)
	{
		if(read_block(block, blockNum) != 0) // getting the block
			return -1;	
		memcpy(&tempFAT[i], block, BLOCKSIZE);	// copying the block to FAT
		blockNum++;
	}
	memcpy(FAT, tempFAT, BLOCKCOUNT*sizeof(int));

	/* initialize the open file table with respect to the number
		of files which could be opened by fil system. */
	for (int i = 0; i < MAXOPENFILES; i++)
	{
		openFileTable[i].available = 1;
	}

	diskLoaded = 1;

	return 0; 
}

int sfs_umount ()
{
    if (diskLoaded == 1)
	{
		// Storing directory back in the disk in blocks 1 and 2

		// Creating a disk block
		char block[BLOCKSIZE];

		// copying first half of the directory to the block
		memcpy(block, directory, 64*(sizeof(struct directEntry)));

		// putting the block into disk
		if(write_block(block, 1) != 0)
			return -1;

		// copying the second half of the directory to the block
		memcpy(block, &directory[64], 64*(sizeof(struct directEntry)));

		// putting the block into disk
		if(write_block(block, 2) != 0)
			return -1;

		// storing FAT in the disk from blocks 8 to 1032
		char tempFAT[BLOCKCOUNT*sizeof(int)];
		memcpy(tempFAT, FAT, BLOCKCOUNT*sizeof(int));

		int blockNum = 8;
		for(int i = 0; i < BLOCKCOUNT*sizeof(int); i = i + BLOCKSIZE)
		{
			memcpy(block, &tempFAT[i], BLOCKSIZE);
			read_block(block, blockNum);
			blockNum++;
		}

		fsync (vdisk_fd); 
		close (vdisk_fd);

		diskLoaded = 0;
	}
	else
		return -1;

	return (0);  
}

int sfs_create(char *filename)
{
	/* checks if the file name exceeds 32 characters. */
	if(strlen(filename) > 32)
	{
		printf("The file name should not exceed 32 characters!\n");
		exit(-1);
	}

	if(diskLoaded == 1)
	{
		/* controlling if the file already exists in the file system. */
		for(int i = 0; i < MAXFILENUMBER; i++)
		{
			if(strcmp(directory[i].fileName, filename) == 0)
			{
				printf("File '%s' already exists in the file system!\n", filename);
				return 0;
			}
		}

		/* if the number of created files are less than 56 and 
			there is an empty space in the directory to store the file. */
		int found = 0;
		for(int i = 0; (i < MAXFILENUMBER) && (found == 0); i++)
		{
			if(directory[i].available == 1)	// empty directory found
			{
				found = 1;
				directory[i].available = 0;
				strcpy(directory[i].fileName, filename);
				directory[i].info.sizeBytes = 0;
				directory[i].info.size = 0;
				printf("file '%s' is created\n", filename);
			}
		}
	}	
	else {
		return -1;
	}

	return -1;
}

int sfs_open(char *file, int mode)
{
    int index = -1;

	if(diskLoaded == 1)
	{
		//file is already open
		int found = 0;
		for(int i = 0; (i < MAXOPENFILES) && (found == 0); i++)
		{
			if((openFileTable[i].available == 0) && (strcmp(openFileTable[i].fileName, file) == 0))
			{
				found = 1;
				/* reset position. */
				openFileTable[i].position = 0;
				openFileTable[i].openCount++;
				
				/* if the file is opened with read only permission set the mode to 0. 
					If the file is opened with write only mode than set the mode to 1.
					Else exit with error message. */
				if (mode == MODE_READ)
				{
					openFileTable[i].mode = 0;
				}
				else if (mode == MODE_APPEND)
				{
					openFileTable[i].mode = 1;
				}
				else
				{
					printf("please enter 0 for read-only mode and 1 for write-only mode when specifying the file opening mode!\n");
					exit(-1);
				}
				
				printf("file '%s' is opened.\n", file);	
				return i;	// if exists then return its handler
			}
		}	

		/* search for file in the directory. */
		int fileFound = 0;
		for(int i = 0; (i < MAXFILENUMBER) && (fileFound == 0); i++)
		{
			/* if the file is found. */
			if( (strcmp(directory[i].fileName, file) == 0) && (directory[i].available == 0) )
			{	
				fileFound = 1;
				int spaceFound = 0;
				/* if there is no 10 files already opened and
					there is an empty space in the open file table. */
				for(int j = 0; (j < MAXOPENFILES) && (spaceFound == 0); j++)
				{
					if (openFileTable[j].available == 1)	// empty space found
					{
						spaceFound = 1;
						openFileTable[j].available = 0;
						openFileTable[j].position = 0;
						openFileTable[i].openCount = 1;
						
						/* if the file is opened with read only permission set the mode to 0. 
							If the file is opened with write only mode than set the mode to 1.
							Else exit with error message. */
						if (mode == MODE_READ)
						{
							openFileTable[i].mode = 0;
						}
						else if (mode == MODE_APPEND)
						{
							openFileTable[i].mode = 1;
						}
						else
						{
							printf("please enter 0 for read-only mode and 1 for write-only mode when specifying the file opening mode!\n");
							exit(-1);
						}

						strcpy(openFileTable[j].fileName, file);
						openFileTable[j].info = &(directory[i].info);
						index = j;
						printf("file '%s' is opened\n", file);
					}
				}
			}
		}
		/* if the file is not in the directory, than exit(the assignment says 
			return -1 on error but it causes segmentation fault) and print error message. */
		if (fileFound == 0)
		{
			printf("the file '%s' is not in the file system!\n", file);
			exit (-1);
		}
	}
	
	return index;  
}

int sfs_close(int fd) 
{
    if(diskLoaded == 1)
	{
		/* if the file is already open. */
		if(openFileTable[fd].available == 0)
		{
			/* decrementing the open file count. */
			openFileTable[fd].openCount--;

			/* file is no longer exists in the openFileTable */
			if(openFileTable[fd].openCount < 1)	
			{
				openFileTable[fd].mode = -1;
				openFileTable[fd].available = 1; 	
			}

			printf("file closed.\n");
			return 0;
		}
		else
		{
			printf("The file you are trying to close is currently not opened!\n");
		}
		
	}

	return -1;  
}

int sfs_getsize (int fd)
{
    int size = -1; 
	
	if(diskLoaded == 1){
		if(openFileTable[fd].available == 0)
			size = openFileTable[fd].info->sizeBytes;
	}	

	printf("size returned.\n");
	return (size);  
}

int sfs_read(int fd, void *buf, int n)
{
    int bytes_read = -1; 

	// mount check
	if(diskLoaded == 1)	
	{
		// is the file already opened control
		if((openFileTable[fd].mode == 0) && (openFileTable[fd].available == 0))	
		{
			// can't read more than 1024 bytes
			if(n <= 1024)	
			{
				// check if atleast one block exists for the file
				if(openFileTable[fd].info->startBlock != -1)	
				{
					// finding the block index to read from	
					int blockReadPosition = openFileTable[fd].position / BLOCKSIZE;

					int blockReadAddress = openFileTable[fd].info->startBlock;
					int i = 0;					
					while(i < blockReadPosition)	
					{
						blockReadAddress = FAT[blockReadAddress];
						i++;
					}

					// finding the displacement within the block
					int displacement;
					if(openFileTable[fd].position < BLOCKSIZE)
						displacement = openFileTable[fd].position;
					else
						displacement = openFileTable[fd].position % BLOCKSIZE;

					// Read from the block
					char block[BLOCKSIZE];
					read_block(block, blockReadAddress);
					bytes_read = 0;
					int blocksFinished = 0;
					char tempBuf[n];
					int tempBufCount = 0;
					while((bytes_read < n) && (blocksFinished == 0) && (bytes_read < openFileTable[fd].info->sizeBytes))
					{
						memcpy( &(tempBuf[tempBufCount]), &(block[displacement]), 1);
						displacement++;
						bytes_read++;
						openFileTable[fd].position++;
						tempBufCount++;

						if(displacement >= BLOCKSIZE)	// If current block full
						{							
							// get the next file block from FAT
							if(FAT[blockReadAddress] != -1)	// check if not last block of file
							{
								blockReadAddress = FAT[blockReadAddress];
								read_block(block, blockReadAddress);	// get the new block
								displacement = 0;
							}
							else
								blocksFinished = 1;
						}
					}					
					memcpy(buf, tempBuf, n);
					printf("reading finished.\n");
				}
			}
		}
		else
		{
			printf("The file you are trying to read is opened with write-only permisson or it is not opened at all!\n");
			exit(-1);
		}
		
	}	
	return (bytes_read); 
}

int sfs_append(int fd, void *buf, int n)
{
    int bytes_written = -1; 

	/* mount check */
	if(diskLoaded == 1)
	{
		/* file opened check. */
		if ((openFileTable[fd].mode == 1) && (openFileTable[fd].available == 0))
		{
			/* upper limit of n check */
			if(n <= MAXREADWRITE)
			{
				char tempBuf[n];
				memcpy(tempBuf, buf, n);

				/* find the place to write */
				if(openFileTable[fd].info->startBlock == -1)
				{
					/* find an empty block. */
					int emptyFound = 0;
					for(int i = 0; (i < BLOCKCOUNT) && (emptyFound == 0); i++)
					{
						/* if there is an empty block. */
						if (FAT[i] == 0) 	
						{
							emptyFound = 1;

							/* block is reserved for the write to be file. */
							openFileTable[fd].info->startBlock = i;
							FAT[i] = -1;

							/* writing operation */
							char block[BLOCKSIZE];							 
							for(int j = 0; j < n; j++)
							{
								memcpy(&(block[j]), &(tempBuf[j]), 1);								
								openFileTable[fd].info->sizeBytes++;
							}
							write_block(block, i);
							openFileTable[fd].position = n;
							bytes_written = n;
							openFileTable[fd].info->size = BLOCKSIZE;		
							printf("write operation is completed.\n");
						}
					}
				}
			}
		}
		else if (openFileTable[fd].mode == 0)
		{
			printf("The file you are trying to write into is opened with read-only permisson or it is not opened at all!\n");
			exit(-1);
		}
		
	}

	return (bytes_written);   
}

int sfs_delete(char *filename)
{
    if(diskLoaded == 1)
	{
		for(int i = 0; i < MAXOPENFILES; i++)
		{
			/* if the file is open, delete operation can't be done.
				First the file should be closed. */
			if(strcmp(openFileTable[i].fileName, filename) == 0 && openFileTable[i].available == 0)
			{
				printf("the file should be closed first!\n");
				return -1;
			}
			else if(strcmp(directory[i].fileName, filename) == 0)
			{
				directory[i].available = 1;

				/* empty FAT table. */
				int entry = directory[i].info.startBlock;
				if(entry != -1)
				{
					while(FAT[entry] != -1)
					{
						int tempEntry = FAT[entry];
						FAT[entry] = 0;
						entry = tempEntry;
					}

					directory[i].info.startBlock = -1;
				}

				return 0;
			}
		}
	}

	return -1;  
}